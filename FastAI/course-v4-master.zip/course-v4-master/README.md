# Please use fastbook's `/clean` folder instead of this

This repo is no longer used - the information that was here is now in the main https://github.com/fastai/fastbook repo, in the folder called `/clean`.
